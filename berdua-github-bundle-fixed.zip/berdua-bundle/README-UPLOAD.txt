BERDUA ANDROID - BUNDLE UNTUK GITHUB ACTIONS

Isi bundle:
- berdua-source.zip: source project, struktur arsip sudah diperiksa.
- .github/workflows/prepare-project-fixed.yml: mengekstrak source ZIP dan commit file project ke root repo.
- .github/workflows/build-apk-fixed.yml: membangun APK debug dan mengunggahnya sebagai artifact.

Langkah:
1. Di repository GitHub berdua-android, unggah berdua-source.zip ke root repository.
2. Pastikan dua workflow YAML berada di .github/workflows/ (jangan di folder .github/workflows/workflows atau di dalam folder project).
3. Buka Actions > Prepare Berdua source from ZIP > Run workflow.
4. Setelah workflow selesai, buka Actions > Build Berdua APK. Jika tidak berjalan otomatis, buka workflow itu dan tekan Run workflow.
5. Buka run yang statusnya hijau, bagian Artifacts, unduh berdua-debug-apk.zip, lalu ekstrak dan instal app-debug.apk di Android.

Catatan: ZIP ini bukan APK. APK belum diklaim berhasil dibuat/diuji; build perlu benar-benar selesai di GitHub Actions. Workflow menghilangkan cache Gradle pada setup-java yang sebelumnya gagal karena project belum berada di root.
